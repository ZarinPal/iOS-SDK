//
//  ZarinPal.h
//  ZarinPal
//
//  Created by Farshid on 5/26/21.
//

#import <Foundation/Foundation.h>

//! Project version number for ZarinPal.
FOUNDATION_EXPORT double ZarinPalVersionNumber;

//! Project version string for ZarinPal.
FOUNDATION_EXPORT const unsigned char ZarinPalVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZarinPal/PublicHeader.h>


