//
//  MPG.h
//  MPG
//
//  Created by ZarinPal on 7/6/21.
//

#import <Foundation/Foundation.h>

//! Project version number for MPG.
FOUNDATION_EXPORT double MPGVersionNumber;

//! Project version string for MPG.
FOUNDATION_EXPORT const unsigned char MPGVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MPG/PublicHeader.h>


